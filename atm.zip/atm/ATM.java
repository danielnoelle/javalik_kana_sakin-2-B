package atm;

import java.util.*;
import java.math.*;
import java.time.LocalDateTime;

public class ATM {
	private static int choice = 0;
	private static String username, password, answer;
	private static Scanner scan = new Scanner(System.in);
	private static User users = new User();
	private static final int LOGIN_OPTION = 1;
	private static final int SIGNUP_OPTION = 2;
	private static final int EXIT_OPTION = 3;
	private static Bank bankSystem = new Bank();
	public static Transaction transactionManager = new Transaction();

	public static void main(String[] args) {

		System.out.println("\n           - ATM - ");
		System.out.println();

		logInMenu: while (true) {
			displayLoginOptionMenu();
			System.out.print("\nEnter your choice here: ");

			try {
				choice = scan.nextInt();
				scan.nextLine();
			} catch (InputMismatchException e) {
				System.out.println("\nInput is not present among the choices. Please try again");

				scan.nextLine();
				continue;
			}

			switch (choice) {
			case LOGIN_OPTION:
				System.out.println();
				login();
				break;
			case SIGNUP_OPTION:
				System.out.println();
				signUp();
				break;
			case EXIT_OPTION:
				System.out.println();
				System.out.print("\nAre you sure?");
				System.out.print("Y/N: ");
				answer = scan.nextLine();
				answer = answer.trim();

				if (answer.equalsIgnoreCase("Y")) {
					break logInMenu;
				} else {
					continue;
				}
			default:
				System.out.println("\nInput is not present among the choices. Please try again");

				continue;
			}

		}

		System.out.println("Thank you for using our program. \nHave a good day!");

	}

	public static void signUp() {

		while (true) {

			if (users.hasUsersReachedCap()) {

				System.out.println("\nSystem in maintenance. Please try again later.");
				return;

			} else {

				System.out.print("\nEnter your username: ");
				username = trimInput(username);

				if (users.isUsernameTaken(username)) {

					System.out.println("\nUsername is taken. Please try again.");
					continue;

				}

				while (true) {
					System.out.println(
							"\nPassword should be at least 8 characters \nand contains at least one number and \none special character.");
					System.out.print("Enter your password: ");
					password = trimInput(username);

					if (password.length() < 8 || !password.matches(".*\\d.*")
							|| !password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) {
						System.out.println("Invalid password! Please try again");
						continue;
					}

					break;
				}

				users.addUser(username, password);
				bankSystem.setUser(username);
				System.out.println("\nRegistered successfully. \nPlease proceed to login.");
				return;

			}
		}
	}

	public static void login() {

		System.out.println();
		System.out.print("Enter your username: ");
		username = trimInput(username);
		System.out.print("Enter your password: ");
		password = trimInput(password);

		if (users.authenticateUser(username, password)) {
			users.setUsername(username);
			users.setPassword(password);
			runATM();
			return;
		}

		System.out.println(
				"\nLogin failed. \nPlease check your username and password. \nSign up first if you don't have an account.");

	}

	public static void displayLoginOptionMenu() {

		System.out.println("\nSelect from the choices below:");
		System.out.println("╔══════════════════════════╗");
		System.out.println("║        Login Menu        ║");
		System.out.println("╠══════════════════════════╣");
		System.out.println("║ 1 - Login                ║");
		System.out.println("║ 2 - Sign Up              ║");
		System.out.println("║ 3 - Exit                 ║");
		System.out.println("╚══════════════════════════╝");

	}

	public static void runATM() {

		bankSystem.setUser(username);
		String currentUser = username;

		accountMenu: while (true) {

			System.out.println();
			System.out.println("Current User: " + currentUser);

			displayAccountMenu();
			System.out.print("Enter your choice here: ");

			try {
				choice = scan.nextInt();
				scan.nextLine();
			} catch (InputMismatchException e) {
				System.out.println("\nInput is not present among the choices. Please try again");
				scan.nextLine();
				continue;
			}

			switch (choice) {
			case 1:
				System.out.println("\nDeposit Amount?");
				System.out.print("Y/N: ");
				answer = trimInput(answer);

				if (answer.equalsIgnoreCase("Y")) {
					depositMoney(bankSystem, currentUser, transactionManager);
				} else {
					continue;
				}
				break;
			case 2:

				if (isLessThanMinimum(100, bankSystem)) {
					continue;
				}

				System.out.println("\nWithdraw Amount?");
				System.out.print("Y/N: ");
				answer = trimInput(answer);

				if (answer.equalsIgnoreCase("Y")) {
					withdrawMoney(bankSystem, currentUser, transactionManager);
				} else {
					continue;
				}
				break;
			case 3:
				checkBalance(bankSystem, currentUser);
				break;
			case 4:

				if (isLessThanMinimum(100, bankSystem)) {
					continue;
				}

				System.out.println("\nSend Money?");
				System.out.print("Y/N: ");
				answer = trimInput(answer);

				if (answer.equalsIgnoreCase("Y")) {
					transferMoney(bankSystem, currentUser, transactionManager);
				} else {
					continue;
				}
				break;
			case 5:
				System.out.println("\nView Transactions?");
				System.out.print("Y/N: ");
				answer = trimInput(answer);

				if (answer.equalsIgnoreCase("Y")) {
					displayTransactions(currentUser);
				} else {
					continue;
				}
				break;
			case 6:
				System.out.println("\nChange PIN?");
				System.out.print("Y/N: ");
				answer = trimInput(answer);

				if (answer.equalsIgnoreCase("Y")) {
					changePassword(currentUser);
				} else {
					continue;
				}
				break;
			case 7:
				System.out.println("\nAre you sure?");
				System.out.print("Y/N: ");
				answer = trimInput(answer);

				if (answer.equalsIgnoreCase("Y")) {
					break accountMenu;
				} else {
					continue;
				}
			default:
				System.out.println("\nInput is not present among the choices. Please try again");
				continue;
			}
		}

	}

	public static void displayAccountMenu() {

		System.out.println("\nWhat would you like to do?");
		System.out.println("╔══════════════════════════╗");
		System.out.println("║       Account Menu       ║");
		System.out.println("╠══════════════════════════╣");
		System.out.println("║ 1 - Deposit              ║");
		System.out.println("║ 2 - Withdraw             ║");
		System.out.println("║ 3 - Check Balance        ║");
		System.out.println("║ 4 - Send Money           ║");
		System.out.println("║ 5 - View Transactions    ║");
		System.out.println("║ 6 - Change PIN           ║");
		System.out.println("║ 7 - Log Out              ║");
		System.out.println("╚══════════════════════════╝");

	}

	public static void depositMoney(Bank bankSystem, String currentUser, Transaction transactionManager) {

		double amount;

		while (true) {

			System.out.print("\nMinimum amount to deposit is ₱100. \nEnter amount to deposit: ₱");

			try {
				amount = scan.nextDouble();
				scan.nextLine();

				if (isLessThanAmount(amount)) {
					displayErrorForAmount();
					continue;
				} else {
					break;
				}

			} catch (InputMismatchException e) {
				displayErrorForAmount();
				scan.nextLine();
				continue;
			}
		}

		bankSystem.depositMoney(amount);
		transactionManager.setUserTransaction(currentUser);
		transactionManager.addTransaction(currentUser, " - Deposit ", getRoundedValue(amount), LocalDateTime.now());
		System.out.println("\nAmount Deposited: ₱" + getRoundedValue(amount));
		System.out.println("New Balance: ₱" + getRoundedValue(bankSystem.getBalance()));

	}

	public static void withdrawMoney(Bank bankSystem, String currentUser, Transaction transactionManager) {

		double amount;

		while (true) {

			if (bankSystem.getBalance() == 0.0) {
				System.out.println("\nInsufficient funds for withdrawal (including tax).");
				return;
			}

			System.out.print("\nMinimum amount to withdraw is ₱100. \nEnter amount to withdraw: ₱");

			try {
				amount = scan.nextDouble();
				scan.nextLine();

				if (isLessThanAmount(amount)) {
					displayErrorForAmount();
					continue;
				} else {
					break;
				}

			} catch (InputMismatchException e) {
				displayErrorForAmount();
				scan.nextLine();
				continue;
			}
		}

		bankSystem.withdrawMoney(amount);

		double totalDeduction = bankSystem.getTotalDeduction();
		double balance = bankSystem.getBalance();

		if (totalDeduction > balance || totalDeduction == balance) {
			System.out.println("\nInsufficient funds for withdrawal (including tax).");
			return;
		} else {
			System.out.println("\nAmount Withdrawn: ₱" + getRoundedValue(amount));
			System.out.println("Withdrawal Tax: ₱" + getRoundedValue(bankSystem.getTotalTax()));
			System.out.println("Total Withdrawal (including tax): ₱" + getRoundedValue(bankSystem.getTotalDeduction()));
			System.out.println("New Balance: ₱" + getRoundedValue(bankSystem.getBalance()));
			ATM.transactionManager.setUserTransaction(getCurrentUser());
			ATM.transactionManager.addTransaction(getCurrentUser(), " - Withdraw ", getRoundedValue(amount),
					LocalDateTime.now());
			return;
		}

	}

	public static void checkBalance(Bank bankSystem, String currentUser) {

		System.out.println("\nYour Balance: ₱" + getRoundedValue(bankSystem.getBalance()));

	}

	public static void transferMoney(Bank bankSystem, String currentUser, Transaction transactionManager) {

		double amount;
		String target = "";

		if (bankSystem.getBalance() == 0.0) {
			System.out.println("\nInsufficient funds for transfer (including tax).");
			return;
		}

		transferMenu: while (true) {
			System.out.print("\nEnter target's username: ");
			target = trimInput(target);
			System.out.println();

			if (users.isTargetUserNotFound(target)) {

				System.out.println("\n" + target + " is not found.");
				System.out.print("\nWould you like to try again? \nY/N: ");

				answer = trimInput(answer);

				if (answer.equalsIgnoreCase("Y")) {
					System.out.println();
					continue transferMenu;
				} else {
					break transferMenu;
				}
			}

			if (users.isTargetCurrentUser(target)) {
				System.out.println("\nYou can't send money to yourself. \nPlease try again.");
				continue;
			}

			while (true) {

				System.out
						.print("Minimum amount to send is ₱100. \nEnter amount to be transferred to " + target + ": ₱");
				try {
					amount = scan.nextDouble();
					scan.nextLine();

					if (isLessThanMinimum(amount, bankSystem)) {
						System.out.println("\nInvalid amount input! Please try again.");
						continue;
					} else if (amount > bankSystem.getBalance()) {
						System.out.println("\nAmount entered is greater than your balance! \nPlease try again.");
						continue;
					} else {
						break;
					}
				} catch (InputMismatchException e) {
					System.out.println("\nInvalid amount input! Please try again.");
					System.out.println();
					continue;
				}
			}

			bankSystem.setTarget(target);
			bankSystem.transferMoney(amount);

			double totalDeduction = bankSystem.getTotalDeduction();
			double balance = bankSystem.getBalance();

			if (totalDeduction > balance || totalDeduction == balance) {
				System.out.println("\nInsufficient funds for sending money (including tax).");
				return;
			} else {
				transactionManager.setUserTransaction(currentUser);
				transactionManager.addTransaction(currentUser, " - Transferred To " + target, getRoundedValue(amount),
						LocalDateTime.now());
				transactionManager.setUserTransaction(target);
				transactionManager.addTransaction(target, " - Received From " + currentUser, getRoundedValue(amount),
						LocalDateTime.now());
				System.out.println("\nSuccessful transfer!");
				System.out.println("User Selected: " + target);
				System.out.println("\nAmount sent: ₱" + getRoundedValue(amount));
				System.out.println("Transferring Tax: ₱" + getRoundedValue(bankSystem.getTotalTax()));
				System.out.println(
						"Total Transferred (including tax): ₱" + getRoundedValue(bankSystem.getTotalDeduction()));
				System.out.println("New Balance: ₱" + getRoundedValue(bankSystem.getBalance()));
			}

			System.out.print("\nWould you like to transfer to another user? \nY/N: ");
			answer = trimInput(answer);

			if (answer.equalsIgnoreCase("Y")) {
				System.out.println();
				continue transferMenu;
			} else {
				break transferMenu;
			}
		}
	}

	public static BigDecimal getRoundedValue(double numberToRound) {

		BigDecimal decimalFormat = new BigDecimal(numberToRound);
		return decimalFormat.setScale(2, RoundingMode.DOWN);

	}

	public static String trimInput(String input) {

		input = scan.nextLine();
		input = input.trim();
		return input;

	}

	public static boolean isLessThanMinimum(double minimum, Bank bankSystem) {
		if (bankSystem.isLessThanMinimum(100)) {

			System.out.println("\nBalance is below ₱100. \nPlease deposit first.");
			return true;
		}

		return false;
	}

	public static boolean isLessThanAmount(double amount) {
		if (amount < 100) {
			return true;
		}

		return false;
	}

	public static void displayErrorForAmount() {
		System.out.println("\nIvalid amount, must be at least ₱100.");
		System.out.println();
	}

	public static void changePassword(String currentUser) {

		String currentPassword = "";
		String newPassword = "";
		System.out.print("\nEnter your current password: ");
		currentPassword = trimInput(currentPassword);

		if (users.isPasswordCorrect(password, currentUser)) {
			System.out.print("Enter your new password: ");
			newPassword = trimInput(newPassword);

			if (newPassword.length() < 8 || !newPassword.matches(".*\\d.*")
					|| !newPassword.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) {
				System.out.println(
						"Password should be at least 8 characters and \ncontains at least one number and one \nspecial character. Please try again.");
				return;
			}

			if (users.changePassword(currentPassword, newPassword)) {
				System.out.println("Password changed successfully!");
				return;
			} else {
				System.out.println("Invalid password! Please try again");
				return;
			}
		}

		System.out.println("\nInvalid password! Please try again");
		return;

	}

	public static void displayTransactions(String currentUser) {

		while (true) {

			displayMenuForTransactions();

			try {
				choice = scan.nextInt();
				scan.nextLine();
			} catch (InputMismatchException e) {
				System.out.println("\nInput is not present among the choices. Please try again");
				scan.nextLine();
				continue;
			}

			switch (choice) {
			case 1:
				System.out.print("\nTransactions for " + currentUser + " ");
				System.out.print("(Sorted By Time in Oldest Order): ");
				System.out.println("\n");
				transactionManager.displayTransactionsByTime(currentUser, true);
				break;
			case 2:
				System.out.print("\nTransactions for " + currentUser + " ");
				System.out.print("(Sorted By Time in Latest Order): ");
				System.out.println("\n");
				transactionManager.displayTransactionsByTime(currentUser, false);
				break;
			case 3:
				System.out.print("\nTransactions for " + currentUser + " ");
				System.out.print("(Sorted By Amount in Ascending Order): ");
				System.out.println("\n");
				transactionManager.displayTransactionsByAmount(currentUser, true);
				break;
			case 4:
				System.out.print("\nTransactions for " + currentUser + " ");
				System.out.print("(Sorted By Amount in Descending Order): ");
				System.out.println("\n");
				transactionManager.displayTransactionsByAmount(currentUser, false);
				break;
			case 5:
				System.out.print("\nTransactions for " + currentUser + " ");
				System.out.print("(Sorted By Action Performed in Ascending Order): ");
				System.out.println("\n");
				transactionManager.displayTransactionsByMessage(currentUser, true);
				break;
			case 6:
				System.out.print("\nTransactions for " + currentUser + " ");
				System.out.print("(Sorted By Action Performed in Descending Order): ");
				System.out.println("\n");
				transactionManager.displayTransactionsByMessage(currentUser, false);
				break;
			case 7:
				return;
			default:
				System.out.println("\nInput is not present among the choices. Please try again");
				scan.nextLine();
				continue;
			}

		}

	}

	public static void displayMenuForTransactions() {

		System.out.println("\nSelect from the choices below:");
		System.out.println("╔═════════════════════════════════════╗");
		System.out.println("║           Transaction Menu          ║");
		System.out.println("╠═════════════════════════════════════╣");
		System.out.println("║ 1 - Display By Time (Oldest)        ║");
		System.out.println("║ 2 - Display By Time (Newest)        ║");
		System.out.println("║ 3 - Display By Amount (Ascending)   ║");
		System.out.println("║ 4 - Display By Amount (Descending)  ║");
		System.out.println("║ 5 - Display By Action (Ascending)   ║");
		System.out.println("║ 6 - Display By Action (Descending)  ║");
		System.out.println("║ 7 - Back to Account Menu            ║");
		System.out.println("╚═════════════════════════════════════╝");
		System.out.print("Enter your choice here: ");
	}

	public static String getCurrentUser() {
		String currentUser = username;
		return currentUser;
	}

}
