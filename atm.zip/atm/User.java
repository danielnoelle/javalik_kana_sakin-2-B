package atm;

public class User {

	private String username, password;
	private final int MAX_USERS = 100;
	private String[][] userCredentials = new String[MAX_USERS][2];
	private int userCount = 0;

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return this.username;
	}

	public String getPassword() {
		return this.password;
	}

	public boolean authenticateUser(String username, String password) {
		for (int i = 0; i < userCount; i++) {
			if (userCredentials[i][0].equals(username) && userCredentials[i][1].equals(password)) {
				return true;
			}

		}

		return false;
	}

	public boolean isUsernameTaken(String username) {
		for (int i = 0; i < userCount; i++) {
			if (userCredentials[i][0] != null && userCredentials[i][0].equals(username))
				return true;
		}
		return false;
	}

	public void addUser(String username, String password) {
		userCredentials[userCount][0] = username;
		userCredentials[userCount][1] = password;
		userCount++;
	}

	public void addUserToBank(String username) {
		Bank bank = new Bank();
		bank.setUser(username);
	}

	public boolean changePassword(String oldPassword, String newPassword) {

		if (password.equals(userCredentials[getCurrentUserIndex(username)][1])) {

			for (int i = 0; i < userCount; i++) {

				if (userCredentials[i][0].equals(username)) {
					if (userCredentials[i][1].equals(oldPassword)) {
						userCredentials[i][1] = newPassword;
						return true;
					}
				}
			}
		}

		return false;
	}

	public int getCurrentUserIndex(String username) {
		for (int i = 0; i < userCount; i++) {

			if (userCredentials[i][0].equals(this.username)) {

				return i;
			}
		}

		return -1;
	}

	public boolean isTargetCurrentUser(String target) {
		if (target.equalsIgnoreCase(userCredentials[getCurrentUserIndex(target)][0])) {
			return true;
		}
		return false;
	}

	public boolean isTargetUserNotFound(String target) {

		for (int i = 0; i < userCount; i++) {
			if (target.equalsIgnoreCase(userCredentials[i][0])) {
				return false;
			}
		}

		return true;
	}

	public boolean hasUsersReachedCap() {

		if (userCount > MAX_USERS) {
			return true;
		}

		return false;
	}

	public boolean isPasswordCorrect(String password, String username) {
		for (int i = 0; i < userCount; i++) {
			if (password.equals(userCredentials[getCurrentUserIndex(username)][1])) {
				return true;
			}
		}

		return false;
	}

}