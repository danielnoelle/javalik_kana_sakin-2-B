package atm;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Transaction {

	private Map<String, List<TransactionInfo>> transactions;

	public Transaction() {
		this.transactions = new HashMap<>();
	}

	private static class TransactionInfo {
		private String message;
		private BigDecimal amount;
		private LocalDateTime date;

		public TransactionInfo(String message, BigDecimal amount, LocalDateTime date) {
			this.message = message;
			this.amount = amount;
			this.date = date;
		}

		public String getMessage() {
			return message;
		}

		public BigDecimal getAmount() {
			return amount;
		}

		public LocalDateTime getDate() {
			return date;
		}
	}

	public void setUserTransaction(String username) {
		this.transactions.putIfAbsent(username, new LinkedList<>());
	}

	public void addTransaction(String username, String message, BigDecimal amount, LocalDateTime date) {
		this.transactions.get(username).add(new TransactionInfo(message, amount, date));
	}

	public void displayTransactionsByTime(String username, boolean ascending) {
		List<TransactionInfo> userTransactions = transactions.get(username);

		Collections.sort(userTransactions, Comparator.comparing(TransactionInfo::getDate));

		if (!ascending) {
			Collections.reverse(userTransactions);
		}

		if (userTransactions != null && !userTransactions.isEmpty()) {
			for (TransactionInfo transactionInfo : userTransactions) {
				System.out.println("• " + formatTransaction(transactionInfo, username));
			}
		} else {
			System.out.println("No transactions available.");
		}

	}

	public void displayTransactionsByAmount(String username, boolean ascending) {
		List<TransactionInfo> userTransactions = transactions.get(username);

		Collections.sort(userTransactions, Comparator.comparing(TransactionInfo::getAmount));

		if (!ascending) {
			Collections.reverse(userTransactions);
		}

		if (userTransactions != null && !userTransactions.isEmpty()) {
			for (TransactionInfo transactionInfo : userTransactions) {
				System.out.println("• " + formatTransaction(transactionInfo, username));
			}
		} else {
			System.out.println("No transactions available.");
		}

	}

	public void displayTransactionsByMessage(String username, boolean ascending) {
		List<TransactionInfo> userTransactions = transactions.get(username);

		Collections.sort(userTransactions, Comparator.comparing(TransactionInfo::getMessage));

		if (!ascending) {
			Collections.reverse(userTransactions);
		}

		if (userTransactions != null && !userTransactions.isEmpty()) {
			for (TransactionInfo transactionInfo : userTransactions) {
				System.out.println("• " + formatTransaction(transactionInfo, username));
			}
		} else {
			System.out.println("No transactions available.");
		}
	}

	private String formatTransaction(TransactionInfo transactionInfo, String username) {
		return username + transactionInfo.getMessage() + " - Amount: ₱" + transactionInfo.getAmount() + " - Date: "
				+ getFormattedDateTime(transactionInfo.getDate());
	}

	private String getFormattedDateTime(LocalDateTime date) {
		return date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
	}

}
