package atm;

import java.util.*;

public class Bank {

	private HashMap<String, Double> balanceOfUsers = new HashMap<>();
	private String user, target;
	private double balance, amount, totalDeduction, totalTax;
	private final double MINIMUM_AMOUNT = 100;
	private final double BASE_WITHDRAWAL_TAX_RATE = 0.03;
	private final double TAX_RATE_INCREASE_THRESHOLD = 500;
	private final double TAX_RATE_INCREASE_AMOUNT = 0.02;

	public void setUser(String user) {
		this.user = user;
		balanceOfUsers.putIfAbsent(user, 0.0);
	}

	public double getBalance() {
		return balanceOfUsers.get(user);
	}

	public void depositMoney(double amount) {
		balance += amount;
		balanceOfUsers.put(user, balance);
	}

	public void withdrawMoney(double amount) {
		double baseTax = amount * BASE_WITHDRAWAL_TAX_RATE;
		double additionalTax = 0;
		if (amount > TAX_RATE_INCREASE_THRESHOLD) {
			additionalTax = (amount - TAX_RATE_INCREASE_THRESHOLD) * TAX_RATE_INCREASE_AMOUNT;
		}
		totalTax = baseTax + additionalTax;
		totalDeduction = amount + totalTax;

		if (totalDeduction > balance || totalDeduction == balance) {
			return;
		} else {
			balance -= totalDeduction;
			balanceOfUsers.put(user, balance);
			this.amount = amount;
			return;
		}

	}

	public boolean isLessThanMinimum(double amount) {
		if (amount < MINIMUM_AMOUNT) {
			return true;
		}
		return false;
	}

	public void transferMoney(double amount) {
		double targetBalance = balanceOfUsers.get(target);
		double baseTax = amount * BASE_WITHDRAWAL_TAX_RATE;
		double additionalTax = 0;
		if (amount > TAX_RATE_INCREASE_THRESHOLD) {
			additionalTax = (amount - TAX_RATE_INCREASE_THRESHOLD) * TAX_RATE_INCREASE_AMOUNT;
		}
		totalTax = baseTax + additionalTax;
		totalDeduction = amount + totalTax;

		if (totalDeduction > balance || totalDeduction == balance) {
			return;
		} else {
			balance -= totalDeduction;
			balanceOfUsers.put(user, balance);
			targetBalance += amount;
			balanceOfUsers.put(target, targetBalance);
			this.amount = amount;
			return;
		}

	}

	public void setTarget(String target) {
		for (String e : balanceOfUsers.keySet()) {

			if (target.equalsIgnoreCase(e)) {
				this.target = e;
				break;
			}
		}

	}

	public String getTarget() {
		return this.target;
	}

	public boolean validateAmount(double amount, String username) {
		if (amount < MINIMUM_AMOUNT) {
			return true;
		}

		if (amount > getBalance()) {
			return true;
		}

		return false;
	}

	public double getAmount() {
		return this.amount;
	}

	public double getTotalDeduction() {
		return this.totalDeduction;
	}

	public double getTotalTax() {
		return this.totalTax;
	}


}
